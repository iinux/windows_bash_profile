﻿Ethervane ActiveHotkeys
Author: marek@tranglos.com
Requirements: Windows 95, XP, Vista, 7 or later (32-bit versions only)
License: Freeware. Copyright © Marek Jedlinski 2012

--- description ---

ActiveHotkeys detects what global keyboard shortcuts (hotkeys) are currently registered on the computer by various applications. This helps you determine which hotkeys are in use, and which are still available.

--- installation ---

(a) STANDARD installation

1. Download the standard installer (setup) file from www.tranglos.com to your computer.

2. Double-click the installer to launch it and follow the on-screen instructions.

3. The program will be installed, and its icon will be added to the Start menu.

To UNINSTALL, use the Add/Remove programs applet in the Control panel.


(b) PORTABLE installation

1. Download the portable installation package (zip file) from www.tranglos.com to your computer.

2. Unpack (unzip) contents of the installation package to any folder on your computer to which you have write permissions.
	IMPORTANT!  NOT unpack the files under C:\Program Files, because the program will not be able to store its configuration there.

3. To start the program double-click the executable file (activehotkeys.exe). You may want to manually create a shortcut to the program in the Start menu.

To UNINSTALL, simply delete the folder containing the program and its configuration files.

--- features ---

Supports all possible combinations of Alt, Ctrl, Shift and Win modifiers with regular typewriter keys.

Results can be sorted and filtered to show all possible hotkeys or only currently active hotkeys (those registered by various applications in the system).

Displays total counts of existing, inactive and currently active hotkeys.

Results can be copied to clipboard or saved to file. Results are copied and saved as tab-delimited format, which can be imported into a spreadsheet.

Settings are saved between sessions.

--- usage ---

1. At the top-left of the screen, under "Select modifier keys", select checkboxes for the modifier keys or chords which you want to test. For example, if you are only interested in shortcuts including the Windows key, select Win, Alt+Win, Ctrl+Win and Shift+Win.

You can right-click this area for additional handy commands. There are commands to select all modifier key combinations, clear all selections, as well as to select all the single key modifiers or 2-, 3- and 4-key chords.

2. Below the top area, under "Select normal key groups", select checkboxes for the key groups you want to test. For example, you may want to test only the alphabetic keys, only numbers, or a combination of the available groups. These selections allow you to limit the number of results, so that finding a particular key is easier.

Right-click this area for additional commands to select all key groups or clear all selections.

Hint: Click the "Key groups" tab to find out what keys are included in each group.

3. Click the "Test active hotkeys" button at the bottom of the screen, or press F9. Results will be displayed in the main pane.

Right-click the listing of results for additional commands:

- Select all results
- Copy selected results to clipboard
- Save selected results to file
- Toggle between showing all results, or only the active (currently registered) hotkeys.

--- limitations ---

Windows does not provide information about what program registered a particular global hotkey. Therefore this information is not available through ActiveHotkeys either.

--- download ---

The latest version can be downloaded from www.tranglos.com

--- support ---

Preferred: Visit the following thread at DonationCoder.com, where the program was first published. Asking there is the quickest way you will receive a reply.
http://www.donationcoder.com/forum/index.php?topic=18189.0

You can also e-mail the author at marek@tranglos.com if you encounter a problem.

--- distribution ---

The program is free to download and use. Written permission from the author is required to bundle, repackage or redistribute the program.

--- history ---

Version 1.3.1: 2012-02-15

- Added support for the VK_APPS key (context menu key)


Version 1.3.0: 2012-02-14

- Portable configuration is now supported (via the master.config file)

- Minor cosmetic changes

- Standard installer available


Version 1.1.0: 2009-05-09 (Play/Pause edition)

- Added support for multimedia and browser keys that some keyboards have. Typically, these keys will be shown as inactive, even though they "work". That is because the operating system does not register these keys as hotkeys with itself. However, some applications (e.g. Winamp), can register these keys, and then you'll see them listed as active.

- The "Show only active keys" option has been replaced with a three-way toggle: Show all, Show only active keys, and Show only inactive keys. The F5 key now cycles through these three options.

- Added an option to display gridlines in the hotkey view (Ctrl+G).

- Added support for the following two command-line switches:
  /localconfig : AH will write its configuration files in the directory where it is installed.
  /nowriteconfig : AH will read its configuration files normally, but will not write back any changes.

- fixed a bug where AH displayed an error message if the "Test active hotkeys" button was clicked while the Key groups or About tab was visible.

- Small cosmetic changes.

Version 1.0: 2009-05-05 (Cinco de Mayo edition)

- Initial release.
